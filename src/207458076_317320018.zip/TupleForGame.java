public class TupleForGame {
    private int gainLeft,gainRight;

    public TupleForGame(int l,int r){
        this.gainRight=r;
        this.gainLeft=l;
    }

    public int getGainRight() {
        return gainRight;
    }

    public void setGainRight(int gainRight) {
        this.gainRight = gainRight;
    }

    public int getGainLeft() {
        return gainLeft;
    }

    public void setGainLeft(int gainLeft) {
        this.gainLeft = gainLeft;
    }
    
    public String toString() {
    	return "("+this.gainLeft+","+this.gainRight+")";
    }

}
