
public class VarTuple {

	private final int i, j;

	public VarTuple(int i, int j) {
		this.i = i;
		this.j = j;
	}
	
	public int getI() {
		return i;
	}

	public int getJ() {
		return j;
	}	
}
