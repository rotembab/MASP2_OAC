
public class TurnMessage implements Message{
	
}
